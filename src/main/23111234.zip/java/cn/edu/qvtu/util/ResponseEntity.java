package cn.edu.qvtu.util;

/**
 * 统一API响应格式
 * 使用泛型支持不同类型的数据返回
 */
public class ResponseEntity {
    private boolean state;      // 操作状态：true成功，false失败
    private String msg;         // 操作结果描述信息
    private Object data;        // 返回的具体数据
    
    // 私有构造方法，强制使用静态工厂方法
    private ResponseEntity(boolean state, String msg, Object data) {
        this.state = state;
        this.msg = msg;
        this.data = data;
    }

    /**
     * 成功响应 - 无数据
     */
    public static ResponseEntity success(String msg) {
        return new ResponseEntity(true, msg, null);
    }

    /**
     * 成功响应 - 有数据
     */
    public static ResponseEntity success(String msg, Object data) {
        return new ResponseEntity(true, msg, data);
    }

    /**
     * 失败响应 - 无数据
     */
    public static ResponseEntity error(String msg) {
        return new ResponseEntity(false, msg, null);
    }

    /**
     * 失败响应 - 有数据
     */
    public static ResponseEntity error(String msg, Object data) {
        return new ResponseEntity(false, msg, data);
    }
    
    // Getter和Setter方法
    public boolean getState() { return state; }
    public void setState(boolean state) { this.state = state; }
    
    public String getMsg() { return msg; }
    public void setMsg(String msg) { this.msg = msg; }
    
    public Object getData() { return data; }
    public void setData(Object data) { this.data = data; }
}